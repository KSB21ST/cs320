package cs320

package object hw01 extends Homework01 {
  // Problem 1
  def dollar2won(dollar: Int): Int = ???
  def volumeOfCuboid(a: Int, b: Int, c: Int): Int = ???
  def isEven(num: Int): Boolean = ???
  def isOdd(num: Int): Boolean = ???
  def gcd(a: Int, b: Int): Int = ???
  def lcm(a: Int, b: Int): Int = ???

  // Problem 2
  def numOfHomework(course: COURSE): Int = ???
  def hasProjects(course: COURSE): Boolean = ???

  // Problem 3
  def namePets(pets: List[String]): List[String] = ???
  def giveName(oldName: String, newName: String): List[String] => List[String] = ???

  def tests: Unit = {
    test(dollar2won(1), 1100)
    test(volumeOfCuboid(1, 2, 3), 6)
    test(isEven(10), true)
    test(isOdd(10), false)
    test(gcd(123, 245), 1)
    test(lcm(123, 245), 30135)
    test(numOfHomework(CS320(quiz = 4, homework = 3)), 3)
    test(hasProjects(CS320(quiz = 3, homework = 9)), false)
    test(namePets(List("dog", "cat", "pig")), List("happy", "smart", "pinky"))
    test(giveName("bear", "pooh")(List("pig", "cat", "bear")), List("pig", "cat", "pooh"))

    /* Write your own tests */
  }
}